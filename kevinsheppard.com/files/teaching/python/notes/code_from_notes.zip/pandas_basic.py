from __future__ import division
from __future__ import print_function
from pylab import *
from numpy import *
from io import StringIO 
from numpy import datetime64
from numpy import sqrt
from numpy.random import choice
from pandas import Categorical
from pandas import DataFrame
from pandas import HDFStore
from pandas import Period
from pandas import Series
from pandas import Timestamp, Timedelta
from pandas import date_range, bdate_range
from pandas import period_range
from pandas import read_csv
from pandas import read_excel
from pandas import to_datetime
from pandas.plotting import scatter_matrix 
import datetime as dt
import itertools
import pandas as pd
import scipy.stats as stats
import seaborn
import sys
# End Imports


a = array([0.1, 1.2, 2.3, 3.4, 4.5])
a
s = Series([0.1, 1.2, 2.3, 3.4, 4.5])
s
s = Series(a) # NumPy array to Series

s = Series([0.1, 1.2, 2.3, 3.4, 4.5], index = ['a','b','c','d','e'])
s

s['a']
s[0]
s.iloc[0]
s[['a','c']]
s[[0,2]]
s[:2]
s[s>2]

s = Series([0.1, 1.2, 2.3, 3.4, 4.5], index = ['a','b','c','a','b'])
s
s['a']

s = Series({'a':0.1 ,'b': 1.2, 'c': 2.3, 'd':3.4, 'e': 4.5})
s

s = Series({'a': 0.1, 'b': 1.2, 'c': 2.3})
s * 2.0
s - 1.0

s1 = Series({'a': 0.1, 'b': 1.2, 'c': 2.3})
s2 = Series({'a': 1.0, 'b': 2.0, 'c': 3.0})
s3 = Series({'c': 0.1, 'd': 1.2, 'e': 2.3})
s1 + s2
s1 * s2
s1 + s3

s1 = Series([1.0,2,3],index=['a'] * 3)
s2 = Series([4.0,5],index=['a'] * 2)
s1 + s2

s1 = Series([1.0,2,3])
s1.values
s1.index
s1.index.values
s1.index = ['cat','dog','elephant']
s1.index

s = Series([1.0,2,3], index=[7,2,8])

try:
    s[0]  # Error 
except:
    print("Error detected in: s[0]  # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))
s[2]

s.iloc[0]
s.iloc[::2]


try:
    s.loc[0] # Error 
except:
    print("Error detected in: s.loc[0] # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))
s.loc[[7,8]]
s.loc[s.index<8]

s1 = Series(arange(10.0,20.0))
s1.describe()
summ = s1.describe()
summ['mean']

s1 = Series(arange(1.0,6),index=['a','a','b','c','d'])
s1
s1.drop('a')

s1 = Series(arange(1.0,4.0),index=['a','b','c'])
s2 = Series(arange(1.0,4.0),index=['c','d','e'])
s3 = s1 + s2
s3
s3.dropna()

s1 = Series(arange(1.0,4.0),index=['a','b','c'])
s2 = Series(arange(1.0,4.0),index=['c','d','e'])
s3 = s1 + s2
s3.fillna(-1.0)

s1 = Series(arange(1.0,4.0),index=['a','b','c'])
s1
s2 = Series(-1.0 * arange(1.0,4.0),index=['c','d','e'])
s1.update(s2)
s1

a = array([[1.0,2],[3,4]])
df = DataFrame(a)
df

df = DataFrame(array([[1,2],[3,4]]),columns=['a','b'])
df
df = DataFrame(array([[1,2],[3,4]]))
df.columns = ['dogs','cats']
df

df = DataFrame(array([[1,2],[3,4]]), columns=['dogs','cats'], index=['Alice','Bob'])
df

t = dtype([('datetime', 'O8'), ('value', 'f4')])
x = zeros(1,dtype=t)
x[0][0] = dt.datetime(2013,1,1)
x[0][1] = -99.99
x
df = DataFrame(x)
df

s1 = Series(arange(0.0,5))
s2 = Series(arange(1.0,3))
DataFrame({'one': s1, 'two': s2})
s3 = Series(arange(0.0,3))
DataFrame({'one': s1, 'two': s2, 'three': s3})

state_gdp = read_excel('US_state_GDP.xls','Sheet1')
state_gdp.head()

state_gdp[['state_code', 'state']]

state_gdp['state_code'].head() # Series
state_gdp[['state_code']].head() # DataFrame
state_gdp[['state_code','state']].head()
cols = state_gdp.columns
state_gdp[cols[1:3]].head()  # Elements 1 and 2 (0-based counting)

state_gdp.state_code.head()
type(state_gdp.state_code)

state_gdp[1:3]

state_long_recession = state_gdp['gdp_growth_2010']<0
state_gdp[state_long_recession].head()

state_gdp.ix[state_long_recession,'state']
state_gdp.ix[state_long_recession,['state','gdp_growth_2009','gdp_growth_2010']]
state_gdp.ix[10:15,0] # Slice and scalar
state_gdp.ix[10:15,:2] # Slice and slice

state_gdp_2012 = state_gdp[['state','gdp_2012']].copy()
state_gdp_2012.head()
state_gdp_2012['gdp_growth_2012'] = state_gdp['gdp_growth_2012']
state_gdp_2012.head()

state_gdp_2012 = state_gdp[['state','gdp_2012']].copy()
state_gdp_2012.insert(1,'gdp_growth_2012',state_gdp['gdp_growth_2012'])
state_gdp_2012.head()

state_gdp_2012 = state_gdp.ix[0:2,['state','gdp_2012']]
state_gdp_2012
gdp_2011 = state_gdp.ix[1:4,'gdp_2011']
state_gdp_2012['gdp_2011'] = gdp_2011

state_gdp_copy = state_gdp.copy()
state_gdp_copy = state_gdp_copy[['state_code','gdp_growth_2011','gdp_growth_2012']]
state_gdp_copy.index = state_gdp['state_code']
state_gdp_copy.head()
gdp_growth_2012 = state_gdp_copy.pop('gdp_growth_2012')
gdp_growth_2012.head()
state_gdp_copy.head()
del state_gdp_copy['gdp_growth_2011']
state_gdp_copy.head()
state_gdp_copy = state_gdp.copy()
state_gdp_copy = state_gdp_copy[['state_code','gdp_growth_2011','gdp_growth_2012']]
state_gdp_dropped = state_gdp_copy.drop(['state_code','gdp_growth_2011'],axis=1)
state_gdp_dropped.head()

df = DataFrame(array([[1, nan],[nan, 2]]))
df.columns = ['one','two']
replacements = {'one':-1, 'two':-2}
df.fillna(value=replacements)

df = DataFrame(array([[1, 3],[1, 2],[3, 2],[2,1]]), columns=['one','two'])
df.sort_values(by='one')
df.sort_values(by=['one','two'])
df.sort_values(by=['one','two'], ascending=[0,1])

prices = [101.0,102.0,103.0]
tickers = ['GOOG','AAPL']
data = [v for v in itertools.product(tickers,prices)]
dates = pd.date_range('2013-01-03',periods=3)
df = DataFrame(data, columns=['ticker','price'])
df['dates'] = dates.append(dates)
df
df.pivot(index='dates',columns='ticker',values='price')

df1 = DataFrame([1,2,3],index=['a','b','c'],columns=['one'])
df2 = DataFrame([4,5,6],index=['c','d','e'],columns=['two'])
pd.concat((df1,df2), axis=1)
pd.concat((df1,df2), axis=1, join='inner')

original = DataFrame([[1,1],[2,2],[3.0,3]],index=['a','b','c'], columns=['one','two'])
original.reindex(index=['b','c','d'])
different = DataFrame([[1,1],[2,2],[3.0,3]],index=['c','d','e'], columns=['one','two'])
original.reindex_like(different)
original.reindex(['two','one'], axis = 1)

left = DataFrame([[1,2],[3,4],[5,6]],columns=['one','two'])
right = DataFrame([[1,2],[3,4],[7,8]],columns=['one','three'])
left.merge(right,on='one') # Same as how='inner'
left.merge(right,on='one', how='left')
left.merge(right,on='one', how='right')
left.merge(right,on='one', how='outer')

left = DataFrame([[1,2],[3,4],[5,6]],columns=['one','two'])
left
right = DataFrame([[nan,12],[13,nan],[nan,8]],columns=['one','two'],index=[1,2,3])
right
left.update(right) # Updates values in left
left

cols = ['gdp_growth_2009', 'gdp_growth_2010',  'gdp_growth_2011', 'gdp_growth_2012']
subset = state_gdp[cols]
subset.index = state_gdp['state_code'].values
subset.head()
subset.apply(mean) # Same as subset.mean()
subset.apply(mean, axis=1).head() # Same as subset.mean(axis=1)

subset = state_gdp[['gdp_growth_2009','gdp_growth_2010','region']]
subset.head()
subset.pivot_table(index='region')

grouped_data = subset.groupby('region')
grouped_data.mean()
grouped_data.std()  # Can use other methods

grouped_data.aggregate(lambda x: x.max() - x.min())

subset_copy = subset.copy()
subset_copy.iloc[::3,:2] = np.nan
subset_copy.head()
filled_data = grouped_data.transform(lambda x:x.fillna(x.mean()))
filled_data.head()

grouped_data = subset.groupby(by='region')
grouped_data.filter(lambda x: x.gdp_growth_2009.max() > 3.3)

subset = state_gdp[['gdp_growth_2009','gdp_growth_2010','region']]
subset.head()
grouped_data = subset.groupby(by='region')
for group_name, group_data in grouped_data:
    if group_name == 'SW':
        print(group_data)

grouped_data.groups # Lists group names and index labels

gender = Series(choice(['M','F'], 1000000))
df = DataFrame(gender)
df.info(memory_usage=True)
gender_cat = Categorical(gender)
df = DataFrame([gender_cat])
df.info(memory_usage=True)

state_gdp.describe()

state_gdp.region.value_counts()

GDP_data = read_excel('GDP.xls','GDP',skiprows=19)
GDP_data.head()
type(GDP_data.VALUE)
gdp = GDP_data.VALUE
gdp.index = GDP_data.DATE
gdp.head()
type(gdp.index)

gdp['2009']
gdp['2009-04'] # All for a particular month

gdp['2009':'2010']
gdp['2009-06-01':'2010-06-01']

gdp.pct_change().tail()
gdp.pct_change(periods=4).tail() # Quarterly data, annual difference

Timestamp('1960-1-1')
Timestamp(datetime64('1960-01-01'))
Timestamp(dt.datetime(1960, 1, 1))

to_datetime(['1960-1-1', '1970-1-1', '1980-1-1'])

Period('1980')
Period(year=1980, freq='A')
Period(year=1980, month=1, freq='Q')
Period(year=1980, month=5, freq='Q')

date_range('2013-01-03','2013-01-05')
date_range('2013-01-03', periods = 3)

date_range('2013-01-03',periods=2, freq='Q')
date_range('2013-01-03',periods=2, freq='BQ')

date_range('2013-01-03',periods=4, freq='Q')
date_range('2013-01-03',periods=4, freq='7D4H')

date_range('2013-01-03', periods=4)
bdate_range('2013-01-03', periods=4)

period_range('2013-01-03', periods=4, freq='M')
period_range('2013-01-03', periods=4, freq='A')
period_range('2013-01-03', '2019-01-01', freq='A')

gdp.resample('A').mean().tail() # Annual average
gdp.resample('A').max().tail() # Maximum

state_gdp.to_excel('state_gdp_from_dataframe.xls')
state_gdp.to_excel('state_gdp_from_dataframe_sheetname.xls', sheet_name='State GDP')
state_gdp.to_excel('state_gdp_from_dataframe.xlsx')
state_gdp.to_csv('state_gdp_from_dataframe.csv')
sio = StringIO()
state_gdp.to_json(sio)
sio.seek(0)
sio.read(50)
state_gdp.to_string()[:50]

df = DataFrame(zeros((1000,1000)))
df.to_csv('size_test.csv')
df.to_hdf('size_test.h5','df') # h5 is the usual extension for HDF5
df.to_hdf('size_test_compressed.h5','df',complib='zlib',complevel=6)
df.to_csv('size_test.csvz', compression='gzip')
df_from_csvz = read_csv('size_test.csvz',compression='gzip')

x = randn(100,100)
DataFrame(x).to_csv('numpy_array.csv',header=False,index=False)

store = HDFStore('store.h5',mode='w',complib='zlib',complevel=6)

store['a'] = DataFrame([[1,2],[3,4]])
store['b'] = DataFrame(np.ones((10,10)))

store.close()

store = HDFStore('store.h5',mode='r')
a = store['a']
b = store['b']
store.close()

with HDFStore('store.h5') as store:
    a = store['a']
    b = store['b']

codes = ['GDPC1','INDPRO','CPILFESL','UNRATE','GS10','GS1','BAA','AAA']
names = ['Real GDP','Industrial Production','Core CPI','Unemployment Rate',\
   '10 Year Yield','1 Year Yield','Baa Yield','Aaa Yield']
# r to disable escape
base_url = r'https://fred.stlouisfed.org/graph/fredgraph.csv?id={code}'

data = []
for code in codes:
    print(code)
    url = base_url.format(code=code)
    data.append(read_csv(url))

time_series = {}
for code, d in zip(codes,data):
    d.index = d.DATE
    time_series[code] = d[code]
merged_data = DataFrame(time_series)
# Unequal length series
print(merged_data)

term_premium = merged_data['GS10'] - merged_data['GS1']
term_premium.name = 'Term'
merged_data = merged_data.join(term_premium,how='outer')
default_premium = merged_data['BAA'] - merged_data['AAA']
default_premium.name = 'Default'
merged_data = merged_data.join(default_premium,how='outer')
merged_data = merged_data.drop(['AAA','BAA','GS10','GS1'],axis=1)
print(merged_data.tail())

quarterly = merged_data.dropna()
print(quarterly.tail())

growth_rates_selector = ['GDPC1','INDPRO','CPILFESL']
growth_rates = 100 * quarterly[growth_rates_selector].pct_change()
final = quarterly.drop(growth_rates_selector, axis=1).join(growth_rates)

new_names = {'GDPC1':'GDP_growth',   \
             'INDPRO':'IP_growth',   \
             'CPILFESL':'Inflation', \
             'UNRATE':'Unemp_rate'}
final = final.rename(columns = new_names ).dropna()
final.to_hdf('FRED_data.h5','FRED',complevel=6,complib='zlib')
final.to_excel('FRED_data.xlsx')

ax = final[['GDP_growth','IP_growth','Unemp_rate']].plot(subplots=True)
fig = ax[0].get_figure()
fig.savefig('FRED_data_line_plot.pdf')
ax = scatter_matrix(final[['GDP_growth','IP_growth','Unemp_rate']], diagonal='kde')
fig = ax[0,0].get_figure()
fig.savefig('FRED_data_scatter_matrix.pdf')


NSW = read_excel('NSW.xls','NSW')
print(NSW.describe())

NSW = NSW.rename(columns={'Real income After ($)':'Income_after',
                          'Real income Before ($)':'Income_before',
                          'Education (years)':'Education'})
NSW['Minority'] = NSW['Black']+NSW['Hispanic']

print(NSW.pivot_table(index='Treated'))
print(NSW.pivot_table(index='Minority'))
print(NSW.pivot_table(index=['Minority','Married']))

ax = NSW[['Income_before','Income_after']].plot(kind='kde',subplots=True)
fig = ax[0].get_figure()
fig.savefig('NSW_density.pdf')

income_diff = NSW['Income_after']-NSW['Income_before']
t = income_diff[NSW['Treated']==1]
nt = income_diff[NSW['Treated']==0]
tstat = (t.mean() - nt.mean())/sqrt(t.var()/t.count() - nt.var()/nt.count())
pval = 1 - stats.norm.cdf(tstat)
print('T-stat: {0:.2f}, P-val: {1:.3f}'.format(tstat,pval))

