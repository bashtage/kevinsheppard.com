from __future__ import print_function, division

__author__ = 'kevin.sheppard'

import subprocess
import glob
import os

files = sorted(glob.glob('*.py'))

if os.name == 'nt':
    python = 'python.exe'
else:
    python = 'python'

print('Current dir' + os.getcwd())

skip = ['custom_functions_and_modules_basic.py',
        'file_system_and_navigation_basic.py',
        'run_all_code.py',
        'pandas_basic.py',
        'performance_cython_basic.py']
for f in enumerate(files):
    print(f)


for f in files:
    if 'example' in f:
        continue
    if f in skip:
        print("Skipping " + f)
        continue
    print("Running " + f)
    out = subprocess.check_output([python, f])
    if out.decode().lower().find("traceback"):
        print(f)
