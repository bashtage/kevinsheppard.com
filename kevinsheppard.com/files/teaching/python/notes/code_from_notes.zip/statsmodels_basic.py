from __future__ import division
from __future__ import print_function
from pylab import *
from numpy import *
import pandas as pd
import statsmodels.api as sm
import sys
# End Imports


data = sm.datasets.statecrime.load_pandas()

data.endog_name
data.exog_name

mod = sm.OLS(data.endog, sm.add_constant(data.exog))
res = mod.fit()
print(res.summary())

print(sorted([v for v in dir(res) if not v.startswith('_')]))

res_white = mod.fit(cov_type='HC0')
se = pd.concat([res.bse, res_white.bse],1)
se.columns = ['No option', 'HC0']
print(se)

df = pd.concat([data.endog, data.exog],1)
mod = sm.OLS.from_formula('murder ~ 1 + urban + single', data=df)
res = mod.fit()

new_mod = sm.OLS.from_formula('murder ~ 1 + urban + single + hs_grad', data=df)
new_res = new_mod.fit()

