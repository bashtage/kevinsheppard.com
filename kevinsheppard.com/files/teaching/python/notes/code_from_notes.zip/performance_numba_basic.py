from __future__ import division
from __future__ import print_function
from pylab import *
from numpy import *
from ctypes import *
from math import pi
from numba import jit
from numba import jit 
from numba import jit, double
from numba import vectorize, float64, complex128
from numpy import abs, reciprocal, roots
from numpy import zeros, empty
from numpy.linalg import cholesky
from numpy.random import randn
import numpy as np
import sys
# End Imports


def garch_recursion(parameters, data, sigma2, p, q, backcast):
    T = np.size(data, 0)
    for i in range(T):
        sigma2[i] = parameters[0]
        for j in range(1, p + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[j] * backcast
            else:
                sigma2[i] += parameters[j] * (data[i - j] * data[i - j])
        for j in range(1, q + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[p + j] * backcast
            else:
                sigma2[i] += parameters[p + j] * sigma2[i - j]
    return sigma2

parameters = array([.1,.1,.8])
data = randn(10000)
sigma2 = zeros(shape(data))
p, q = 1,1
backcast = 1.0

@jit
def garch_recursion_numba_jit(parameters, data, sigma2, p, q, backcast):
    T = np.size(data, 0)
    for i in range(T):
        sigma2[i] = parameters[0]
        for j in range(1, p + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[j] * backcast
            else:
                sigma2[i] += parameters[j] * (data[i - j] * data[i - j])
        for j in range(1, q + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[p + j] * backcast
            else:
                sigma2[i] += parameters[p + j] * sigma2[i - j]
    return sigma2

garch_recursion_numba_jit(parameters, data, sigma2, p, q, backcast) # Warmup
'The speed-up is {0:.1f} times'.format(0.0248/0.0000548 - 1.0)

garch_recursion_numba_jit_command = jit(garch_recursion)

'The speed-up is {0:.1f} times'.format(0.0248/0.0000559 - 1.0)

def pydot(a, b):
    M,N = shape(a)
    P,Q = shape(b)
    c = zeros((M,Q))
    for i in range(M):
        for j in range(Q):
            for k in range(N):
                c[i,j] += a[i,k] * b[k,j]
    return c
@jit
def pydot_jit(a, b):
    M,N = shape(a)
    P,Q = shape(b)
    c = zeros((M,Q))
    for i in range(M):
        for j in range(Q):
            for k in range(N):
                c[i,j] += a[i,k] * b[k,j]
    return c

'The speed-up is {0:.1f} times'.format(0.83/.00239 - 1.0)
pydot_jit_descr =jit('double[:,::1](double[:,::1],double[:,::1])')(pydot)

def list_sel(x, i):
    return x[[i]]

try:
    nb_list_sel = jit(list_sel, nopython=True) # Error 
except:
    print("Error detected in: nb_list_sel = jit(list_sel, nopython=True) # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))
x = randn(4,4)
list_sel(x,2)

def slice_sel(x, i):
    return x[i:i+1]
nb_slice_sel = jit(slice_sel, nopython=True)
slice_sel(x,2)
nb_slice_sel(x,2)

def kalman_simulate(tau,T,R,Z,H):
    H12 = cholesky(H)
    R12 = cholesky(R)
    k = H.shape[0]
    m = R.shape[0]
    eps = randn(tau,k) @ H12
    eta = randn(tau,m) @ R12
    alpha = empty((tau,m))
    y = empty((tau,k))
    alpha[0] = eta[0] @ (eye(m) - T@T)
    y[0] = alpha[0] @ Z + eps[0]
    for t in range(1, tau):
        alpha[t] = alpha[t-1] @ T + eta[t]
        y[t] = alpha[t] @ Z + eps[t]
    return alpha, y
kalman_simulate_jit = jit(kalman_simulate, nopython=True)

tau = 1000
k = 3
m = 2
H = 0.7 * np.eye(k) + 0.3 * np.ones((k,k))
R = (eye(m) - (ones((m,m)) - eye(m)) / m)
T = 0.9 * eye(m)
Z = 2 * (rand(m,k) - 1)
kalman_simulate_jit(tau, T, R, Z, H)

tau = 1000
k = 100
m = 10
H = 0.7 * np.eye(k) + 0.3 * np.ones((k,k))
R = (eye(m) - (ones((m,m)) - eye(m)) / m)
T = 0.9 * eye(m)
Z = 2 * (rand(m,k) - 1)

@vectorize([float64(complex128,complex128,complex128)])
def largest_root(p1,p2,p3):
    return reciprocal(abs(roots(array([-p3,-p2,-p1,1])))).max()

p1 = linspace(-3, 3, 100)
p2 = linspace(-3, 3, 100)
p3 = linspace(-1, 1, 100)
largest_root(p1,p2,p3)
p1.shape = (100,1)
absroot = largest_root(p1,p2,p3)
absroot.shape
p1.shape = (100,1,1)
p2.shape = (1,100,1)
p3.shape = (1,1,100)
absroot = largest_root(p1,p2,p3)
absroot.shape

@vectorize([float64(complex128,complex128,complex128)], target='parallel')
def largest_root(p1,p2,p3):
    return reciprocal(abs(roots(array([-p3,-p2,-p1,1])))).max()

absroot = largest_root(p1,p2,p3)

# Setup
T = 10000# 1 year
nstep = 23400  # 1 second
p0, v0 = 0.0, 0.0
# Model Parameters
mu = 0.03
b0 = 0.000
b1 = 0.125
alpha = -0.100
rho = -0.62
# Initialize daily vectors
log_closing_price = np.zeros(T, dtype=np.float64)
integrated_variance = np.zeros(T, dtype=np.float64)
# Initialize intradaily vectors
v = np.zeros(nstep + 1, dtype=np.float64)
spot_vol = np.zeros(nstep + 1, dtype=np.float64)
p = np.zeros(nstep + 1, dtype=np.float64)
p[0] = p0
v[0] = v0
R_root = np.linalg.cholesky(np.array([[1, rho], [rho, 1]])).T
dt = 1.0 / nstep #/ 252
root_dt = np.sqrt(dt)
for t in range(T):
    e = np.random.standard_normal((nstep, 2)).dot(R_root) * root_dt
    dwp = e[:, 0]
    dwv = e[:, 1]
    # Replacement function
    # innerloop_jit(mu, alpha, b0, b1, nstep, p, v, spot_vol, dt, dwv, dwp)
    # Key loop
    #for i in range(1, nstep + 1):
    #    dv = alpha * v[i - 1] * dt + dwv[i - 1]
    #    v[i] = v[i - 1] + dv
    #    spot_vol[i] = np.exp(b0 + b1 * v[i - 1])
    #    dp = mu * dt + spot_vol[i] * dwp[i - 1]
    #    p[i] = p[i - 1] + dp

    # Save data
    integrated_variance[t] = np.mean(spot_vol ** 2.0)
    log_closing_price[t] = p[-1]
    # Reset the first price for the next day
    p[0] = p[-1]
    v[0] = v[-1]

for i in range(1, nstep):
    dv = alpha * v[i - 1] * dt + dwv[i]
    v[i] = v[i - 1] + dv
    spot_vol[i] = np.exp(b0 + b1 * v[i - 1])
    dp = mu * dt + spot_vol[i] * dwp[i]
    p[i] = p[i - 1] + dp

@jit
def innerloop(mu, alpha, b0, b1, nstep, p, v, spot_vol, dt, dwv, dwp):
    for i in range(1, nstep):
        dv = alpha * v[i - 1] * dt + dwv[i]
        v[i] = v[i - 1] + dv
        spot_vol[i] = np.exp(b0 + b1 * v[i - 1])
        dp = mu * dt + spot_vol[i] * dwp[i]
        p[i] = p[i - 1] + dp

proc = cdll.msvcrt
# Linux/OSX
# proc = CDLL(None)
c_exp = proc.exp
c_exp.argtypes = [c_double]
c_exp.restype = c_double
@jit
def use_numpy_exp(x):
    return np.exp(x)
@jit
def use_c_exp(x):
    return c_exp(x)

