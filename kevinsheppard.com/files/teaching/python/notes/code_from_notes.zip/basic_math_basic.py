from __future__ import division
from __future__ import print_function
from pylab import *
from numpy import *
import sys
# End Imports


x = array([[1,2,3.0]])
x
y = array([[0],[0],[0.0]])
y
x + y  # Adding 0 produces broadcast

x = reshape(arange(15),(3,5))
x
y = 5
x + y - x
y = arange(5)
y
x + y - x
y = arange(3)
y

try:
    x + y - x # Error 
except:
    print("Error detected in: x + y - x # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))

x = array([[1.0, 2],[ 3, 2], [3, 4]])
y = array([[9.0, 8],[7, 6]])
x @ y
x.dot(y)

try:
    2 @ x # Error 
except:
    print("Error detected in: 2 @ x # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))
2 * x

x = asmatrix(randn(2,2))
xpx1 = x.T * x
xpx2 = x.transpose() * x
xpx3 = transpose(x) * x

