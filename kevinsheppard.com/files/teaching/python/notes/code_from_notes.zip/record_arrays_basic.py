from __future__ import division
from __future__ import print_function
from pylab import *
from numpy import *
import datetime as dt
import datetime as dt 
import sys
# End Imports


x = zeros(4,[('date','int'),('ret','float')])
x = zeros(4,{'names': ('date','ret'), 'formats': ('int', 'float')})
x

x['date']
x['ret']

x[0] # Data tuple 0
x[:3] # Data tuples 0, 1 and 2

try:
    x[:,1] # Error 
except:
    print("Error detected in: x[:,1] # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))

type = dtype([('var1','f8'), ('var2','i8'), ('var3','u8')])
type

ba_type = dtype([('bid','f8'), ('ask','f8')])
t = dtype([('date', 'O8'), ('prices', ba_type)])
data = zeros(2,t)
data
data['prices']
data['prices']['bid']

x = array([dt.datetime.now()])
x.dtype.itemsize # The size in bytes
x.dtype.descr # The name and description

t = dtype([('date', 'u4'), ('time', 'u4'),
           ('size', 'u4'), ('price', 'f8'),
           ('g127', 'u2'), ('corr', 'u2'),
           ('cond', 'S2'), ('ex', 'S2')])
taqData = zeros(10, dtype=t)
taqData[0] = (20120201,120139,1,53.21,0,0,'','N')

t = dtype([('datetime', 'O8'), ('size', 'u4'), ('price', 'f8'), \
           ('g127', 'u2'), ('corr', 'u2'), ('cond', 'S2'), ('ex', 'S2')])
taqData = zeros(10, dtype=t)
taqData[0] = (dt.datetime(2012,2,1,12,1,39),1,53.21,0,0,'','N')

x = zeros((4,1),[('date','int'),('ret','float')])
y = rec.array(x)
y.date
y.date[0]

