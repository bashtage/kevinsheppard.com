from pylab import *
from numpy import *
from matplotlib import rc
from matplotlib.pyplot import figure, draw
from matplotlib.pyplot import figure, plot, bar, pie, draw, scatter
from matplotlib.pyplot import figure, plot, legend, draw
from matplotlib.pyplot import figure, plot_date, axis, draw
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d import Axes3D 
from numpy import cumsum
from numpy import linspace
from numpy import linspace, meshgrid, mat, zeros, shape, sqrt
from numpy import sqrt, arange
from numpy.random import randn
from numpy.random import randn, rand
from pandas.plotting import register_matplotlib_converters
import datetime as dt
import matplotlib.cm as cm
import matplotlib.dates as mdates
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import numpy.linalg as linalg
import pandas as pd
import scipy.stats as stats
import seaborn as sns
import sys
# End Imports



register_matplotlib_converters()


y = randn(100)
plot(y)
autoscale(tight='x')
tight_layout()

plot(y,'g--')

x = cumsum(rand(100))
plot(x,y,'r-')

plot(x,y,alpha = 0.5, color = '#FF7F00', \
   label = 'Line Label', linestyle = '-.', \
   linewidth = 3, marker = 'o', markeredgecolor = '#000000', \
   markeredgewidth = 2, markerfacecolor = '#FF7F00', \
   markersize=30)

h = plot(randn(10))
getp(h)
setp(h, 'alpha')
setp(h, 'color')
setp(h, 'linestyle')
setp(h, 'linestyle', '--') # Change the line style

z = randn(100,2)
z[:,1] = 0.5*z[:,0] + sqrt(0.5)*z[:,1]
x=z[:,0]
y=z[:,1]
scatter(x,y)

scatter(x,y, s = 60,  c = '#FF7F00', marker='s', \
    alpha = .5, label = 'Scatter Data')

size_data = exp(exp(exp(rand(100))))
size_data = 200 * size_data/amax(size_data)
size_data[size_data<1]=1.0
scatter(x,y, s = size_data, c = '#FF7F00', marker='s', \
    label = 'Scatter Data')

y = rand(5)
x = arange(5)
bar(x,y)

bar(x,y, width = 0.5, color = '#FF7F00', \
    edgecolor = '#000000', linewidth = 5)

colors = sns.color_palette('colorblind')
barh(x, y, height = 0.5, color = colors, \
     edgecolor = '#000000', linewidth = 5)

y = rand(5)
y = y/sum(y)
y[y<.05] = .05
pie(y, normalize=True)

explode = array([.2,0,0,0,0])
colors = sns.dark_palette("skyblue", 8, reverse=True)
labels = ['One', 'Two', 'Three', 'Four', 'Five']
pie(y, explode=explode, colors=colors, labels=labels, \
    autopct = '%2.0f', shadow = True, normalize=True)

x = randn(1000)
hist(x, bins = 30)

hist(x, bins = 30, cumulative=True, color='#FF7F00')

fig = figure()
# Add the subplot to the figure
# Panel 1
ax = fig.add_subplot(2, 2, 1)
y = randn(100)
plot(y)
ax.set_title('1')
# Panel  2
y = rand(5)
x = arange(5)
ax = fig.add_subplot(2, 2, 2)
bar(x, y)
ax.set_title('2')
# Panel 3
y = rand(5)
y = y / sum(y)
y[y < .05] = .05
ax = fig.add_subplot(2, 2, 3)
pie(y, colors=colors, normalize=True)
ax.set_title('3')
# Panel 4
z = randn(100, 2)
z[:, 1] = 0.5 * z[:, 0] + sqrt(0.5) * z[:, 1]
x = z[:, 0]
y = z[:, 1]
ax = fig.add_subplot(2, 2, 4)
scatter(x, y)
ax.set_title('4')
draw()

x = randn(100)
fig = figure()
ax = fig.add_subplot(111)
ax.hist(x, bins=30, label='Empirical')
xlim = ax.get_xlim()
ylim = ax.get_ylim()
pdfx = linspace(xlim[0], xlim[1], 200)
pdfy = stats.norm.pdf(pdfx)
pdfy = pdfy / pdfy.max() * ylim[1]
plot(pdfx, pdfy, 'r-', label='PDF')
ax.set_ylim((ylim[0], 1.2 * ylim[1]))
legend()
draw()

x = cumsum(randn(100,3), axis = 0)
plot(x[:,0],'b-',label = 'Series 1')
plot(x[:,1],'g-.',label = 'Series 2')
plot(x[:,2],'r:',label = 'Series 3')
legend()
title('Basic Legend')

plot(x[:,0],'b-',label = 'Series 1')
plot(x[:,1],'g-.',label = 'Series 2')
plot(x[:,2],'r:',label = 'Series 3')
legend(loc = 0, frameon = False, title = 'The Legend')
title('Improved Legend')

# Simulate data
T = 2000
x = []
for i in range(T):
    x.append(dt.datetime(2012,3,1)+dt.timedelta(i,0,0))
y = cumsum(randn(T))

fig = figure()
ax = fig.add_subplot(111)
ax.plot(x,y)
draw()

fig.autofmt_xdate()
draw()

T = 100
x = []
for i in range(1,T+1):
    x.append(dt.datetime(2012,3,1)+dt.timedelta(i,0,0))
y = cumsum(randn(T))

fig = figure()
ax = fig.add_subplot(111)
ax.plot(x,y)
draw()

fig.autofmt_xdate()
draw()

months = mdates.MonthLocator()
ax.xaxis.set_major_locator(months)
fmt = mdates.DateFormatter('%b %Y')
ax.xaxis.set_major_formatter(fmt)
fig.autofmt_xdate()
draw()

xlim = list(ax.get_xlim())
xlim[0] = mdates.date2num(dt.datetime(2012,3,1))
ax.set_xlim(xlim)
draw()

# Reading the data
# pd.read_csv is the best method to read csv data
recessionDates = pd.read_csv('USREC.csv', index_col='DATE', parse_dates=True)
capacityUtilization = pd.read_csv('TCU.csv', index_col='DATE', parse_dates=True)
# Merge the two data sets and keep the common rows
combined = pd.concat([recessionDates, capacityUtilization], axis=1).dropna()
# Find the data after the first date
plotData = capacityUtilization.loc[combined.index]
shadeData = recessionDates.loc[combined.index]

# The shaded plot
x = plotData.index
y = plotData.values
# z is the shading values, 1 or 0, need to be 1-d
z = (shadeData != 0).squeeze()
# Figure
fig = figure()
ax = fig.add_subplot(111)
plot_date(x,y,'r-')
limits = axis()
font = { 'fontname':'Times New Roman', 'fontsize':14 }
ax.fill_between(x, limits[2], limits[3], where=z, edgecolor='#BBBBBB', \
    facecolor='#222222', alpha=0.3)
axis(ymin=limits[2])
ax.set_title('Capacity Utilization',font)
xl = ax.get_xticklabels()
for label in xl:
    label.set_fontname('Times New Roman')
    label.set_fontsize(14)
    label.set_rotation(45)
yl = ax.get_yticklabels()
for label in yl:
    label.set_fontname('Times New Roman')
    label.set_fontsize(14)
draw()

rc('text', usetex=True)
rc('font', family='serif')
y = 50*exp(.0004 + cumsum(.01*randn(100)))
plot(y)
xlabel(r'time ($\tau$)')
ylabel(r'Price',fontsize=16)
title(r'Geometric Random Walk: $d\ln p_t = \mu dt + \sigma dW_t$',fontsize=16)
rc('text', usetex=False)

x = linspace(0,6*pi,600)
z = x.copy()
y = sin(x)
x=  cos(x)
fig = plt.figure()
ax = Axes3D(fig, auto_add_to_figure=False)
fig.add_axes(ax)
ax.plot(x, y, zs=z, label='Spiral')
ax.view_init(15,45)
plt.draw()

x = linspace(-3,3,100)
y = linspace(-3,3,100)
x,y = meshgrid(x,y)
z = zeros((1,2))
p = zeros(shape(x))
R = array([[1,.5],[.5,1]])
Rinv = linalg.inv(R)
for i in range(len(x)):
    for j in range(len(y)):
        z[0,0] = x[i,j]
        z[0,1] = y[i,j]
        p[i,j] = 1.0/(2*pi)*sqrt(linalg.det(R))*exp(-(z@Rinv@z.T)/2)

fig = plt.figure()
ax = Axes3D(fig, auto_add_to_figure=False)
fig.add_axes(ax)
ax.plot_wireframe(x, y, p, rstride=5, cstride=5, color='#AD5300')
ax.view_init(29,80)
plt.draw()

fig = plt.figure()
ax = Axes3D(fig, auto_add_to_figure=False)
fig.add_axes(ax)
ax.plot_surface(x, y, p, rstride=2, cstride=2, cmap=cm.coolwarm, shade='interp')
ax.view_init(29,80)
plt.draw()

fig = plt.figure()
ax = fig.gca()
ax.contour(x,y,p)
plt.draw()

plot(randn(10,2))
savefig('figure.pdf') # PDF export
savefig('figure.png') # PNG export
savefig('figure.svg') # Scalable Vector Graphics export

plot(randn(10,2))
savefig('figure.png', dpi = 600) # High resolution PNG export

