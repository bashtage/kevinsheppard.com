from pylab import *
from numpy import *
cdef extern from "garch_recursion_standalone.h":
cdef extern from "math.h":
cimport cython
cimport numpy as np
from Cython.Distutils import build_ext
from distutils.core import setup
from distutils.extension import Extension
from numba import jit
import ctypes as ct
import cython_weighted_avg as c
import garch_ext
import garch_recursion_dll_wrapper as dll
import garch_recursion_wrapper as wrapper
import numpy
import numpy as np
import pydot as p
import sys
# End Imports


# garch_ext.pyx
@cython.boundscheck(False)
@cython.wraparound(False)
def garch_recursion(double[::1] parameters not None,
                    double[::1] data not None,
                    double[::1] sigma2 not None,
                    int p,
                    int q,
                    double backcast):
    cdef int T = np.size(data, 0)
    cdef int i, j
    for i in range(T):
        sigma2[i] = parameters[0]
        for j in range(1, p + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[j] * backcast
            else:
                sigma2[i] += parameters[j] * (data[i - j] * data[i - j])
        for j in range(1, q + 1):
            if (i - j) < 0:
                sigma2[i] += parameters[p + j] * backcast
            else:
                sigma2[i] += parameters[p + j] * sigma2[i - j]
    return sigma2

# setup.py
setup(
    cmdclass = {'build_ext': build_ext},
    ext_modules = [Extension("garch_ext", ["garch_ext.pyx"])],
    include_dirs = [numpy.get_include()]
)

parameters = array([.1,.1,.8])
data = randn(10000)
sigma2 = zeros(shape(data))
p,q = 1,1
backcast = 1.0
f'The speed-up is {.0279/.0000551 - 1.00:.1f} times'

@cython.boundscheck(False)
@cython.wraparound(False)
def pydot(double[:, ::1] a not None,
          double[:, ::1] b not None):
    cdef int M, N, P, Q
    M,N = np.shape(a)
    P,Q = np.shape(b)
    assert N==P
    cdef double[:, ::1] c = np.zeros((M,N), dtype=np.float64)
    for i in range(M):
        for j in range(Q):
            for k in range(N):
                c[i,j] = c[i,j] + a[i,k] * b[k,j]
    return c

a = randn(100,100)
b = randn(100,100)
f'The speed-up is {0.907/0.00272- 1.0:.1f} times'
f'The speed-up is {0.00272/0.0000248 - 1.0:.1f} times'

def naive_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    m12 = int(ceil(m/2))
    y = zeros(T)
    for i in range(len(x)-m+1):
        for j in range(m):
            y[i+m12] += x[i+j] * w[j]
    return y

@cython.boundscheck(False)
@cython.wraparound(False)
def cython_weighted_avg(double[::1] x,
                        double[::1] w):
    cdef int T, m, m12, i, j
    T = x.shape[0]
    m = len(w)
    m12 = int(np.ceil(float(m)/2))
    cdef double[::1] y = np.zeros(T, dtype=np.float64)
    for i in range(T-m+1):
        for j in range(m):
            y[i+m12] += x[i+j] * w[j]
    return y

w = array(r_[1:11,9:0:-1],dtype=float64)
w = w/sum(w)
x = randn(10000)
weighted_avg_jit = jit(naive_weighted_avg)

def egarch_recursion(parameters, data, backcast):
	T = np.size(data,0)
	lnsigma2 = np.zeros(T)
	sigma2 = np.zeros(T)
    lnsigma2[0] = backcast
    for t in range(1, T):
		sigma2[t-1] = np.exp(lnsigma2[t-1])
        lnsigma2[t] = parameters[0]
                      + parameters[1] * data[t-1] / sigma2[t]
                      + parameters[2] * lnsigma2[t-1]
    sigma2[T - 1] = np.exp(lnsigma2[t])
    return sigma2

@cython.boundscheck(False)
@cython.wraparound(False)
@cython.cdivision(True)
def egarch_recursion(double[::1] parameters not None,
                     double[::1] data not None,
                     double backcast):
    cdef int T = np.size(data, 0)
    cdef int t
    cdef double lnsigma2
    cdef double[::1] sigma2 = np.zeros(T, dtype=np.float64)
    lnsigma2 = backcast
    for t in range(1, T):
        sigma2[t - 1] = np.exp(lnsigma2)
        lnsigma2 = parameters[0] \
                   + parameters[1] * data[t - 1] / sigma2[t]  \
                   + parameters[2] * lnsigma2
    sigma2[T - 1] = np.exp(lnsigma2[t])
    return sigma2

    double exp(double x)
@cython.boundscheck(False)
@cython.wraparound(False)
@cython.cdivision(True)
def egarch_recursion(double[::1] parameters not None,
                     double[::1] data not None,
                     double backcast):
    cdef int T = np.size(data, 0)
    cdef int t
    cdef double lnsigma2
    cdef double[::1] sigma2 = np.zeros(T, dtype=np.float64)
    lnsigma2 = backcast
    for t in range(1, T):
        sigma2[t - 1] = exp(lnsigma2)
        lnsigma2 = parameters[0] \
                   + parameters[1] * data[t - 1] / sigma2[t]  \
                   + parameters[2] * lnsigma2
    sigma2[T - 1] = exp(lnsigma2[t])
    return sigma2

// garch_recursion.h
__declspec(dllexport) void garch_recursion(int T, double *parameters, double *data, double *sigma2, int p, int q, double backcast);

// garch_recursion.c
#include "garch_recursion.h"
#ifdef WIN32
#define WINAPI __declspec(dllexport)
#else
#define WINAPI
#endif
WINAPI void garch_recursion(int T, double *parameters, double *data, double *sigma2, int p, int q, double backcast)
{
	int i, j;
	for(i = 0; i<T; i++)
	{
		sigma2[i] = parameters[0];
		for (j=1; j<=p; j++)
		{
			if((i-j)<0)
			{
				sigma2[i] += parameters[j] * backcast;
			}
			else
			{
				sigma2[i] += parameters[j] * (data[i-j]*data[i-j]);
			}
		}
		for (j=1; j<=q; j++)
		{
			if((i-j)<0)
			{
				sigma2[i] += parameters[p+j] * backcast;
			}
			else
			{
				sigma2[i] += parameters[p+j] * sigma2[i-j];
			}
		}
	}
}

cl.exe -nologo -EHsc -GS -W3 -D_WIN32 -D_USRDLL -MD -Ox -c garch_recursion.c
link.exe /nologo /DLL garch_recursion.obj /OUT:garch_recursion.dll

gcc -O3 -Wall -ansi -pedantic -c -fPIC garch_recursion.c -o garch_recursion.o
gcc garch_recursion.o -shared -o garch_recursion.so

# garch_recursion_dll_wrapper.py
# Open the library
garchlib = np.ctypeslib.load_library("garch_recursion.dll", '.')
# Linux/OSX
# garchlib = np.ctypeslib.load_library("garch_recursion.so", '.')
# Define output and input types
garchlib.garch_recursion.restype = ct.c_void_p
garchlib.garch_recursion.argtypes = [ct.c_int,
                                     ct.POINTER(ct.c_double),
                                     ct.POINTER(ct.c_double),
                                     ct.POINTER(ct.c_double),
                                     ct.c_int,
                                     ct.c_int,
                                     ct.c_double]
# Wrapper function
def garch_recursion(parameters, data, sigma2, p, q, backcast):
    # Optional, but can be important if data is not contiguous
    # Will copy to temporary value, only if needed
    parameters = np.ascontiguousarray(parameters)
    data = np.ascontiguousarray(data)
    sigma2 = np.ascontiguousarray(sigma2)
    T = data.shape[0]
    return garchlib.garch_recursion(T,
                                    parameters.ctypes.data_as(ct.POINTER(ct.c_double)),
                                    data.ctypes.data_as(ct.POINTER(ct.c_double)),
                                    sigma2.ctypes.data_as(ct.POINTER(ct.c_double)),
                                    p,
                                    q,
                                    backcast)


# garch_recursion_wrapper.pyx
    void garch_recursion(int T, double * parameters, double * data, double * sigma2,
                         int p, int q, double backcast)
@cython.boundscheck(False)
def garch_recursion_wrapped(double[:] parameters not None,
                           double[:] data not None,
                           double[:] sigma2 not None,
                           int p,
                           int q,
                           double backcast):
    cdef int T = np.size(data, 0)
    # Best practice is to ensure arrays are contiguous
    parameters = np.ascontiguousarray(parameters)
    data = np.ascontiguousarray(data)
    sigma2 = np.ascontiguousarray(sigma2)

    # No return, sigma2 modified in place
    garch_recursion(T, &parameters[0] , &data[0], &sigma2[0], p, q, backcast)
    return sigma2

# setup_garch_recursion_wrapper.py
ext_modules = [Extension(
    name="garch_recursion_wrapper",
    sources=["garch_recursion_wrapper.pyx", "garch_recursion.c"],
    include_dirs = [numpy.get_include()])]
setup(
    name = 'garch_recursion_wrapper',
    cmdclass = {'build_ext': build_ext},
    ext_modules = ext_modules)


