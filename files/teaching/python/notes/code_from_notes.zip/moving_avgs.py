from numpy import ceil, zeros, dot, copy, vstack, flipud, reshape, tile, array, float64, r_
from numpy.random import randn


# import __builtin__
#
# try:
#    __builtin__.profile
# except AttributeError:
#    # No line profiler, provide a pass-through version
#    def profile(func): return func
#    __builtin__.profile = profile
#


# @profile
def naive_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    m12 = int(ceil(m / 2))
    y = zeros(T)
    for i in range(len(x) - m + 1):
        y[i + m12] = dot(x[i:i + m].T, w)

    return y


# @profile
def clever_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    wc = copy(w)
    wc.shape = m, 1
    T = x.size
    xc = copy(x)
    xc.shape = T, 1
    y = vstack((xc, zeros((m, 1))))
    y = tile(y, (m, 1))

    y = reshape(y[:len(y) - m], (m, T + m - 1))
    y = y.T
    y = y[m - 1:T, :]

    return dot(y, flipud(wc))


# @profile
def sideways_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    y = zeros(T)
    m12 = int(ceil(m / 2))
    for i in range(m):
        y[m12:T - m + m12] = x[i:T + i - m] * w[i]

    return y


w = array(r_[1:11, 9:0:-1], dtype=float64)
w = w / sum(w)
x = randn(100000)

naive_weighted_avg(x, w)
clever_weighted_avg(x, w)
sideways_weighted_avg(x, w)
