from pylab import *
from numpy import *
from statsmodels.datasets.sunspots import load_pandas
from statsmodels.tsa.api import SARIMAX
import pandas as pd
import statsmodels.api as sm
import sys
# End Imports


data = sm.datasets.statecrime.load_pandas()

data.endog_name
data.exog_name

mod = sm.OLS(data.endog, sm.add_constant(data.exog))
res = mod.fit()
print(res.summary())

print(sorted([v for v in dir(res) if not v.startswith('_')]))

res_white = mod.fit(cov_type='HC0')
se = pd.concat([res.bse, res_white.bse], axis=1)
se.columns = ['No option', 'HC0']
print(se)

df = pd.concat([data.endog, data.exog], axis=1)
mod = sm.OLS.from_formula('murder ~ 1 + urban + single', data=df)
res = mod.fit()

new_mod = sm.OLS.from_formula('murder ~ 1 + urban + single + hs_grad', data=df)
new_res = new_mod.fit()

star98 = sm.datasets.star98.load_pandas().data
formula = 'SUCCESS ~ LOWINC + PERASIAN + PERBLACK + PERHISP + PCTCHRT + PCTYRRND'
success = star98['NABOVE'] / (star98['NABOVE'] + star98['NBELOW'])
star98['SUCCESS'] = success
cols = ['LOWINC', 'PERASIAN', 'PERBLACK','PERHISP', 'PCTCHRT','PCTYRRND']
dta = star98.drop('NABOVE', axis=1)
mod = sm.GLM.from_formula(formula, dta, family=sm.families.Binomial())
res = mod.fit()
res.summary()

data = load_pandas().data
activity = data.SUNACTIVITY
model = SARIMAX(activity, order=(1,0,0), seasonal_order=(0,1,0,13))
result = model.fit()
result.summary()

