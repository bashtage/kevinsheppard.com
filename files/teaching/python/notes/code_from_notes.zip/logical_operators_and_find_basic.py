from pylab import *
from numpy import *
import sys
# End Imports


x = array([[1,2],[-3,-4]])
x > 0
x == -3
y = array([1,-1])
x < y # y broadcast to be (2,2)
z = array([[1,1],[-1,-1]]) # Same as broadcast y
x < z

x = arange(-2.0,4)
y = x >= 0
z = x < 2
logical_and(y, z)
y & z
(x > 0) & (x < 2)

try:
    x > 0 & x < 4 # Error 
except:
    print("Error detected in: x > 0 & x < 4 # Error")
    error = sys.exc_info()
    print("Error type: " + str(error[0]) + " Error message: " + str(error[1]))
~(y & z) # Not

x = array([[1, 2], [3, 4]])
y = x <= 2
y
any(y)
any(y,0)
any(y,1)

eps = np.finfo(np.float64).eps
eps
x = randn(2)
y = x + eps
x == y
allclose(x,y)

x = randn(10,1)
y = tile(x,2)
array_equal(x,y)
array_equiv(x,y)

x=array([4,pi,inf,inf/inf])
x
isnan(x)
isinf(x)
isfinite(x)

