r"""Demonstration module.
This is the module docstring.
"""

def square(x):
    r"""Returns the square of a scalar input
    """
    return x*x

def cube(x):
    r"""Returns the cube of a scalar input
    """
    return x*x*x