from pylab import *
from numpy import *
from numpy.random import Generator, SeedSequence
from numpy.random import default_rng
import sys
# End Imports


gen = default_rng()  # Totally random initialization
poorly_seeded_gen = default_rng(0)
seeded_gen = default_rng(121405155939511953)

x = gen.random((3,4,5))

y = gen.standard_normal((3,4,5))

z = gen.integers(0,10,size=100)
z.max()  # Is 9 since range is [0,10)
w = gen.integers(0, 100, size=10000, endpoint=True)
w.max()  # 100 since endpoint is True

x = arange(10)
gen.shuffle(x)
x

x = arange(10)
gen.permutation(x)
x

x = arange(10)
gen.choice(x, 4)
gen.choice(4, replace=False)

st = gen.bit_generator.state
gen.standard_normal(4)
gen.bit_generator.state = st
gen.standard_normal(4)

entropy = 8438478419318319783739213
seed_seq = SeedSequence(entropy)  # Transform the entropy
prng = PCG64(seed_seq)  # The PRNG
gen = Generator(prng)  # Set the PRNG in the Generator

seed_seq = SeedSequence(seed)
children = seed_seq.spawn(10)
gens = [default_rng(child) for child in children]

x = rand(3,4,5)
y = random_sample((3,4,5))

x = randn(3,4,5)
y = standard_normal((3,4,5))

x = randint(0,10,(100))
x.max() # Is 9 since range is [0,10)

x = arange(10)
shuffle(x)
x

x = arange(10)
permutation(x)
x

gen1 = np.random.RandomState()
gen2 = np.random.RandomState()
gen1.uniform() # Generate a uniform
state1 = gen1.get_state()
gen1.uniform()
gen2.uniform() # Different, since gen2 has different seed
gen2.set_state(state1)
gen2.uniform() # Same uniform as gen1 after assigning state

st = get_state()
randn(4)
set_state(st)
randn(4)

seed()
randn()
seed()
randn()
seed(0)
randn()
seed(0)
randn()

