from pylab import *
from numpy import *
from moving_avgs import clever_weighted_avg
from moving_avgs import naive_weighted_avg
from moving_avgs import sideways_weighted_avg 
from numpy import ceil, zeros, copy, vstack, flipud, reshape, tile, array, float64, r_
from numpy.random import randn
import IPython
import line_profiler 
import sys
# End Imports


x = randn(1000,1000)
x = randn(100,100)

def pydot(a, b):
    M,N = shape(a)
    P,Q = shape(b)
    c = zeros((M,Q))
    for i in range(M):
        for j in range(Q):
            for k in range(N):
                c[i,j] += a[i,k] * b[k,j]
    return c

a = randn(100,100)
b = randn(100,100)
f'The speed-up is {0.83/0.0000534 - 1.0:.1f} times'

def naive_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    m12 = int(ceil(m/2))
    y = zeros(T)
    for i in range(len(x)-m+1):
        y[i+m12] = x[i:i+m].T @ w
    return y

w = array(r_[1:11,9:0:-1],dtype=float64)
w = w/sum(w)
x = randn(10000)

def clever_weighted_avg(x,w):
    T = x.shape[0]
    m = len(w)
    wc = copy(w)
    wc.shape = m,1
    T = x.size
    xc = copy(x)
    xc.shape=T,1
    y = vstack((xc,zeros((m,1))))
    y = tile(y,(m,1))
    y = reshape(y[:len(y)-m],(m,T+m-1))
    y = y.T
    y = y[m-1:T,:]

    return y @ flipud(wc)


def sideways_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    y = zeros(T)
    m12 = int(ceil(m/2))
    for i in range(m):
        y[m12:T-m+m12] = x[i:T+i-m] * w[i]
    return y


x = randn(1000,1)
y = randn(1,1000)

x = zeros(1000000)

x = arange(16.0)
x.shape = 4,4
x


w = array(r_[1:11,9:0:-1],dtype=float64)
w = w/sum(w)
x = randn(100000)



# Useful block but not necessary
try:
    profile
except (NameError, AttributeError):
    # No line profiler, provide a pass-through version
    def profile(func):
        return func
# Useful block but not necessary
@profile
def naive_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    m12 = int(ceil(m/2))
    y = zeros(T)
    for i in range(len(x)-m+1):
        y[i+m12] = x[i:i+m].T @ w
    return y
@profile
def clever_weighted_avg(x,w):
    T = x.shape[0]
    m = len(w)
    wc = copy(w)
    wc.shape = m,1
    T = x.size
    xc = copy(x)
    xc.shape=T,1
    y = vstack((xc,zeros((m,1))))
    y = tile(y,(m,1))
    y = reshape(y[:len(y)-m],(m,T+m-1))
    y = y.T
    y = y[m-1:T,:]
    return y @ flipud(wc)
@profile
def sideways_weighted_avg(x, w):
    T = x.shape[0]
    m = len(w)
    y = zeros(T)
    m12 = int(ceil(m/2))
    y = zeros(x.shape)
    for i in range(m):
        y[m12:T-m+m12] = x[i:T+i-m] * w[i]
    return y
w = array(r_[1:11,9:0:-1],dtype=float64)
w = w/sum(w)
x = randn(100000)
naive_weighted_avg(x,w)
clever_weighted_avg(x,w)
sideways_weighted_avg(x,w)

# Useful block but not necessary
try:
    profile
except NameError:
    # No line profiler, provide a pass-through version
    def profile(func):
        return func
# Useful block but not necessary

