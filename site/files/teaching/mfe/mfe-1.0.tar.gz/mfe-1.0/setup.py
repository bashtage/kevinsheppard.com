from setuptools import find_packages, setup

setup(
    name="mfe",
    version="1.0",
    description="Common code for MFE notes",
    author="Kevin Sheppard",
    author_email="kevin.k.sheppard@gmail.com",
    license="Proprietary",
    packages=find_packages(),
    zip_safe=False,
)
