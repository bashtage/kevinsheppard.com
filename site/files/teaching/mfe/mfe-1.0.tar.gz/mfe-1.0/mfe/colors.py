import seaborn as sns

colors = sns.color_palette("tab10")
