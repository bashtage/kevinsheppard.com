import matplotlib.font_manager
import numpy as np

matplotlib.font_manager._rebuild()
import matplotlib as mpl
import matplotlib.axes
import matplotlib.figure
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.axes import Axes

from mfe.colors import colors

mpl.rcParams["font.family"] = "serif"
mpl.rcParams["image.cmap"] = "tab10"
# mpl.rcParams['pdf.fonttype'] = 42
# mpl.rcParams['ps.fonttype'] = 42


LATEX_BASE = [
    r"\usepackage[utopia]{mathdesign}",
]


LATEX_FINAL = [
    r"\usepackage[T1]{fontenc}",
    r"\usepackage[utf8]{inputenc}",
    r"\usepackage{amsmath}",
    r"\usepackage{babel}",
    r"\usepackage[utopia]{mathdesign}",
    r"\DeclareSymbolFont{symbols}{OMS}{cmsy}{m}{n}",
    r"\DeclareSymbolFont{largesymbols}{OMX}{cmex}{m}{n}",
    r"\DeclareSymbolFontAlphabet{\mathcal}{symbols}",
]


SANS_LATEX = (
    LATEX_BASE
    + [
        # r"\usepackage[scaled]{helvet}",
        r"\usepackage[default]{cantarell}",
        # r"\usepackage{arev}",
        r"\usepackage[T1]{fontenc}",
        # r"\renewcommand\familydefault{\sfdefault}",
        r"\usepackage[T1]{fontenc}",
        r"\usepackage{helvet}",  # set the normal font here
        r"\usepackage{sansmath}",  # load up the sansmath so that math -> helvet
        r"\sansmath",  # <- tricky! -- gotta actually tell tex to use!
    ]
    + LATEX_FINAL
)

SERIF_LATEX = LATEX_BASE + [r"\usepackage[utopia]{mathdesign}"] + LATEX_FINAL


def common_config():
    mpl.rcParams["font.family"] = "serif"
    mpl.rcParams["font.serif"] = [
        "Utopia Std",
        "Georgia",
        "Bitstream Vera Serif",
    ]  # ["Utopia Std", "Georgia", "Bitstream Vera Serif"]
    mpl.rcParams["image.cmap"] = "tab10"
    mpl.rcParams["lines.linewidth"] = 4
    mpl.rcParams["ytick.major.size"] = 8
    mpl.rcParams["ytick.major.width"] = 2
    mpl.rcParams["xtick.major.size"] = 8
    mpl.rcParams["xtick.major.width"] = 2


def notes():
    common_config()
    rc = {
        "text.latex.preamble": "\n".join(SERIF_LATEX),
        "text.usetex": True,
        "font.family": "serif",
        "font.serif": ["Utopia Std", "Georgia", "Bitstream Vera Serif"],
    }
    mpl.rcParams.update(rc)


def pres():
    common_config()
    rc = {
        "text.latex.preamble": "\n".join(SANS_LATEX),
        "text.usetex": True,
        "font.family": "sans-serif",
        "font.sans-serif": ["cantarell", "Arial", "Calibri"],
    }
    mpl.rcParams.update(rc)


outputs = {"pres": pres, "notes": notes}


def half_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (20, 16 / 2)
    mpl.rcParams["font.size"] = 34


def half_setup_wide():
    common_config()
    mpl.rcParams["figure.figsize"] = (26, 16 / 2)
    mpl.rcParams["font.size"] = 40


def third_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (20, 16 / 3)
    mpl.rcParams["font.size"] = 40


def sixth_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (20, 16 / 2)
    mpl.rcParams["font.size"] = 60


def full_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (20, 16)
    mpl.rcParams["font.size"] = 34


def full_setup_wide():
    common_config()
    mpl.rcParams["figure.figsize"] = (32, 16)
    mpl.rcParams["font.size"] = 42


def quarter_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (10, 8)
    mpl.rcParams["font.size"] = 34


def quarter_setup_wide():
    common_config()
    mpl.rcParams["figure.figsize"] = (12, 8)
    mpl.rcParams["font.size"] = 34


def quarter_setup_ultra_wide():
    common_config()
    mpl.rcParams["figure.figsize"] = (16, 8)
    mpl.rcParams["font.size"] = 44


def quarter_setup_square():
    common_config()
    mpl.rcParams["figure.figsize"] = (8, 10)
    mpl.rcParams["font.size"] = 34


def ninth_setup():
    common_config()
    mpl.rcParams["figure.figsize"] = (12, 10)
    mpl.rcParams["font.size"] = 54


def plot() -> (matplotlib.figure.Figure, matplotlib.axes.Axes):
    return plt.subplots(1, 1)


def savefig(fig: matplotlib.figure.Figure, filename: str, **kwargs):
    if not filename.endswith(".pdf"):
        filename += ".pdf"
    fig.savefig("../figures/" + filename, transparent=True, **kwargs)


def show():
    plt.show()


if __name__ == "__main__":
    setups = [full_setup, half_setup, third_setup, quarter_setup]
    import numpy as np
    import pandas as pd
    import seaborn as sns

    df = pd.DataFrame(
        np.cumsum(np.random.randn(250)),
        columns=["rw"],
        index=pd.date_range("1999-12-31", periods=250),
    )
    for s in setups:
        s()
        print(s.__name__)
        print(mpl.rcParams["figure.figsize"])
        for out in outputs:
            outputs[out]()
            f, a = plot()
            df.plot(ax=a)
            sns.despine()
            f.tight_layout(pad=1.0)
            plt.show()
            stype = s.__name__ + "-" + out
            savefig(f, stype)


def is_int_like(v):
    try:
        tv = np.array(v, dtype=np.int64)
        return np.all(np.array(v) == tv)
    except:
        return False


def stringify_labels(axis: Axes, x=True, y=True, x_format=None, y_format=None):
    def f(ticks, format):
        if format is None and is_int_like(ticks):
            ticks = np.array(ticks, dtype=np.int64)
        return ticks

    def guess_format(t):
        t = np.asarray(t)
        if t.dtype == np.int64:
            return "{:d}"
        try:
            for i in range(3):
                if np.all(np.round(t, (i + 1)) == np.round(t, (i + 2))):
                    return f"{{:0.{i + 1}f}}"
        except:
            return "{0}"

    if x:
        ticks = f(axis.get_xticks(), x_format)
        x_format = guess_format(ticks) if x_format is None else x_format
        axis.set_xticks(axis.get_xticks())
        axis.set_xticklabels([x_format.format(t) for t in ticks])
    if y:
        ticks = f(axis.get_yticks(), y_format)
        y_format = guess_format(ticks) if y_format is None else y_format
        axis.set_yticks(axis.get_yticks())
        axis.set_yticklabels([y_format.format(t) for t in ticks])


def left_brace(x, y, height, width, flat_height):
    b0 = np.linspace(0, 2 * np.pi / 4, 201)
    b1 = np.linspace(np.pi, 3 * np.pi / 2, 201)
    _x = np.r_[np.sin(b0), [1, 1], 2 + np.sin(b1)[::-1]]
    _y = np.r_[np.cos(b0), [0, -flat_height], np.cos(b1)[::-1] - flat_height]
    _y = _y - np.max(_y)
    x2 = np.r_[_x[::-1], _x]
    y2 = np.r_[-_y[::-1], _y]
    x2 = x2 / (np.max(x2) - np.min(x2))
    y2 = y2 / (np.max(y2) - np.min(y2))
    x2 = x2 * width
    y2 = y2 * height

    x2 = x2 + x
    y2 = y2 + y
    return x2, y2


def right_brace(x, y, height, width, flat_height):
    x2, y2 = left_brace(0, 0, height, width, flat_height)
    x2 *= -1
    x2 += x
    y2 += y
    return x2, y2


DEFAULT_FIGSIZE = (32, 15)


def setup_rise():
    plt.rc("figure", figsize=DEFAULT_FIGSIZE)
    plt.rc("font", size=42)


def pretty(s):
    from IPython.display import HTML, display

    if not isinstance(s, pd.Series):
        return display(HTML(f"<span>{s}</span>"))

    df = pd.DataFrame(s)
    if df.columns[0] == 0:
        df.columns = [""]
    return df


def figsize(x=DEFAULT_FIGSIZE[0], y=DEFAULT_FIGSIZE[1]):
    plt.rc("figure", figsize=(x, y))
