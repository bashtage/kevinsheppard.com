from typing import Union

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from IPython.display import HTML, display

from mfe.colors import colors

LAST_COLOR_INDEX = 0
MAX_COLOR_INDEX = 8
DEFAULT_FIGSIZE = (32, 14)
plt.rc("figure", figsize=DEFAULT_FIGSIZE)
plt.rc("font", size=48)


def figsize(x=DEFAULT_FIGSIZE[0], y=DEFAULT_FIGSIZE[1]):
    if x <= 0:
        x += DEFAULT_FIGSIZE[0]
    if y <= 0:
        y += DEFAULT_FIGSIZE[1]
    plt.rc("figure", figsize=(x, y))


def plot(s: pd.Series, y=DEFAULT_FIGSIZE[1], loc=None):
    global LAST_COLOR_INDEX
    figsize(y=y)
    fig, ax = plt.subplots(1, 1)
    if isinstance(s, pd.Series):
        s.plot(ax=ax, legend=False, color=colors[LAST_COLOR_INDEX])
    else:
        s.plot(ax=ax, legend=False)
        fig.legend(frameon=False, loc=loc)
    LAST_COLOR_INDEX += 1
    LAST_COLOR_INDEX = LAST_COLOR_INDEX % MAX_COLOR_INDEX
    ax.set_xlabel(None)
    ax.set_xlim(s.index[0], s.index[-1])
    sns.despine()
    fig.tight_layout(pad=1.0)
    figsize()


def truncated_plot(s: pd.Series, p: Union[int, float], y=DEFAULT_FIGSIZE[1]):
    global LAST_COLOR_INDEX
    figsize(y=y)
    fig, ax = plt.subplots(1, 1)
    if isinstance(s, pd.Series):
        s.plot(ax=ax, legend=False, color=colors[LAST_COLOR_INDEX])
    else:
        s.plot(ax=ax, legend=False)
        fig.legend(frameon=False)
    bnd = s.quantile(p / 100.0)
    if not isinstance(bnd, float):
        bnd = np.min(bnd)
    LAST_COLOR_INDEX += 1
    LAST_COLOR_INDEX = LAST_COLOR_INDEX % MAX_COLOR_INDEX
    ax.set_xlabel(None)
    ax.set_xlim(s.index[0], s.index[-1])
    ax.set_ylim(0, bnd)
    sns.despine()
    fig.tight_layout(pad=1.0)
    figsize()


def pretty(s):
    if not isinstance(s, pd.Series):
        return display(HTML(f"<span>{s}</span>"))

    df = pd.DataFrame(s)
    if df.columns[0] == 0:
        df.columns = [""]
    return df


def summary(res, idx=(1,)):
    summ = res.summary()
    for i in idx:
        html = summ.tables[i]._repr_html_()
        if i == 0:
            html = html.split("</tr>")
            html = "</tr>".join(html[:-8] + html[-1:])
            html = html.replace("<caption>OLS Regression Results</caption>", "")
        display(HTML(html))
    return None
